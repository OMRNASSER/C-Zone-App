import 'package:flutter/material.dart';

const primaryColor = Color.fromRGBO(0, 197, 105, 100);
